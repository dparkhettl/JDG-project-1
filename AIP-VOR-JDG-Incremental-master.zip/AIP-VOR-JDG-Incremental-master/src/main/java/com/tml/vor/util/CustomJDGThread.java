package com.tml.vor.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tml.vor.esb.VORUIResponse;
import com.tml.vor.service.JdgService;
import com.tml.vor.service.VORUIService;
import com.tml.vor.util.CustomJDGThread;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.Callable;

public class CustomJDGThread implements Callable<Boolean> {
	
	private static Logger logger = LoggerFactory.getLogger(CustomJDGThread.class);
	
    private LocalDate startDate;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");    
    private JdgService jdgServiceImpl;
    private VORUIService jdgConnectionServiceImpl;

    private List<VORUIResponse> VORUIResponseList;

    public CustomJDGThread(LocalDate startDate, JdgService jdgServiceImpl, VORUIService jdgConnectionServiceImpl) {
        this.startDate = startDate;
        this.jdgServiceImpl = jdgServiceImpl;
        this.jdgConnectionServiceImpl = jdgConnectionServiceImpl;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

     @Override
    public Boolean call() throws Exception {
        logger.info("Inside Method CustomJDGThread.call...");
        String formatStartDate= this.startDate.format(formatter);
        VORUIResponseList= this.jdgConnectionServiceImpl.findByStartDate(formatStartDate);
        logger.info("VORUIResponseList size --> "+VORUIResponseList.size());
        logger.info("Exiting Method CustomJDGThread.call...");
        return this.jdgServiceImpl.put(VORUIResponseList);
    }
}

