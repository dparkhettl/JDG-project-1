package com.tml.vor.config;

public interface JdgConstants {
	
	 String CACHE_NAME = "DigiVORCache";//"VORCache";

}
