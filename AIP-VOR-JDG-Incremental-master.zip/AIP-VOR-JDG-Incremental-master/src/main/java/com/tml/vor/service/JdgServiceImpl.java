package com.tml.vor.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.Search;
import org.infinispan.commons.util.CloseableIteratorSet;
import org.infinispan.query.dsl.Query;
import org.infinispan.query.dsl.QueryFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tml.vor.config.JdgConnection;
import com.tml.vor.config.JdgConstants;
import com.tml.vor.config.JdgProperties;
import com.tml.vor.esb.VORUIResponse;
import com.tml.vor.util.CustomJDGThread;

@Service
public class JdgServiceImpl implements JdgService {
	
	
	private static Logger logger = LoggerFactory.getLogger(JdgServiceImpl.class);
	private RemoteCache<Integer, Object> cache;
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
	private ObjectMapper mapper = new ObjectMapper();
	private Integer cacheObjectCounter = 0;
	private VORUIService vorUiService;

	private JdgProperties jdgProperties;

	public JdgServiceImpl(VORUIService vorUiService, JdgProperties jdgProperties, JdgConnection jdgConnection) {
        logger.info("Creating Bean of class JdgServiceImpl...");
        this.jdgProperties = jdgProperties;
        this.vorUiService = vorUiService;
        try {
            this.cache = jdgConnection.getCache(JdgConstants.CACHE_NAME);
            this.mapper.setDateFormat(sdf);
            this.mapper.configure(Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
            this.mapper.configure(Feature.ALLOW_NUMERIC_LEADING_ZEROS, true);
        } catch (Exception e) {
            logger.error(
                    "Exception occurred while creating bean of class JdgConnectionManagerImpl with cache name {} and exception {}",
                    JdgConstants.CACHE_NAME, e.toString());
        }
        logger.info("Exiting Constructor of class JdgServiceImpl...");
    }
	
			
	@Override
    public boolean put(List<VORUIResponse> vorUiResponseList) {
        logger.info("Inside Method  JdgServiceImpl.put to add records in JDG...");
        
        if (vorUiResponseList != null && vorUiResponseList.size() != 0) {
        	logger.info("Number Of Records inserted in JDG :" + vorUiResponseList.size());
            
            try {            	
                getUpdatedIndexValueFromCache();
                //Start Search and remove the record from Cash 
                logger.info("Before remove size on Cash--> "+this.cache.size());
                for (VORUIResponse vorUiResponse : vorUiResponseList) { 
                    CloseableIteratorSet<Entry<Integer, Object>> remoteCatch= this.cache.entrySet();
                    for (Entry<Integer, Object> setEntry:remoteCatch) {
                    	VORUIResponse response=(VORUIResponse) setEntry.getValue();
                    	if(response.getPar_row_id().equalsIgnoreCase(vorUiResponse.getPar_row_id())) {
                    		logger.info("response.getPar_row_id() " + response.getPar_row_id() + "-- vorUiResponse:  "+vorUiResponse.getPar_row_id());
                    		this.cache.remove(setEntry.getKey());
                    	}
                    }
                }
                logger.info("After remove size on Cash--> "+this.cache.size());
                //end Search and remove the record from Cash
                
                // Start Insert new/updated data in cash
                logger.info("Before insert size on Cash--> "+this.cache.size());	
                for (VORUIResponse vorUiResponse : vorUiResponseList) {
                	logger.info("Insert data into Cash...");                	
                    this.cacheObjectCounter += 1;
                    this.cache.put(this.cacheObjectCounter, vorUiResponse);
                } 
                logger.info("After inssert size on Cash--> "+this.cache.size());	
                // End Insert new/updated data in cash
                
            } catch (Exception e) {
                logger.error("Exception occurred while putting data in cache {}", e.toString());
                return false;
            }
        }
        
        logger.info("Exiting Method JdgServiceImpl.put...");
        return true;
    }		  

	    public boolean putAll(String startDat) throws Exception {
	    	logger.info("Inside Method JdgServiceImpl.putAll...");
	    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	    	logger.info("before startDat-->"+startDat);
	    	LocalDate startDate = LocalDate.parse(startDat, formatter);
	    	
	    	startDate = startDate.minusDays(1);	
	    	logger.info("After startDat-->"+startDat);
	        ExecutorService executorService = Executors.newSingleThreadExecutor();
	        Set<Callable<Boolean>> callables = new HashSet<>();
	        LocalDate tmpStartDate = startDate;
	        
	        for (int i = 0; i < jdgProperties.getTotalValue(); i++) {	            
	                logger.info("Current start data to fetch data : " + tmpStartDate);
	                callables.add(new CustomJDGThread(tmpStartDate, this, this.vorUiService));
	        }
	        executorService.invokeAll(callables);
	        logger.info("Exiting Method JdgConnectionManagerImpl.putAll...");
	        return false;
	    }
	
	    private void getUpdatedIndexValueFromCache() {
	        logger.info("Inside Method  JdgServiceImpl.getUpdatedIndexValueFromCache..."+ this.cache);	
	        this.cacheObjectCounter = this.cache.size();	
	        logger.info("Exiting Method JdgServiceImpl.getUpdatedIndexValueFromCache...");
	    }
	    
	    @Override
		public Set<VORUIResponse> searchRecordInJDG(String paramRowId) throws Exception {
	    	logger.info("Inside Method  JdgConnectionManagerImpl.searchRecordInJDG...");	    	
			QueryFactory qf = Search.getQueryFactory(this.cache);
			
			Query query = null;
			query = qf.from(VORUIResponse.class).build();
			logger.info("query-->" + query.toString());
			List<VORUIResponse> tmpList = query.list();
			logger.info("tmpList size-->" + tmpList.size());
			
			if ((paramRowId != null && !paramRowId.equals("")) ) {			
					tmpList = tmpList.stream().filter((VORUIResponse accountObject) ->(accountObject.getPar_row_id().equals(paramRowId))
				).collect(Collectors.toList());
				logger.info("tmpList" + tmpList.toString());				
			} 
			Set<VORUIResponse> matches = new HashSet<>();
			matches.addAll(tmpList);
			
			logger.info("Matches size -->" + matches.size());
			logger.info("Exiting Method JdgConnectionManagerImpl.searsearchRecordInJDGch...");
			return matches;
		}
	

}
