package com.tml.vor.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.tml.vor.esb.VORUIResponse;

public interface JdgService {
	    /*
	     * Override this method to put single entry in JDG Cache
	     */
	    boolean put(List<VORUIResponse> VORUIResponseList) throws Exception;
	    /*
	     * Put all data of time period
	     */
	    boolean putAll(String startDate) throws Exception;
		//Set<VORUIResponse> searchRecordInJDG(Map<String, String> paramMap) throws Exception;
		Set<VORUIResponse> searchRecordInJDG(String paramRowId) throws Exception;

}
