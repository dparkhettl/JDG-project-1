package com.tml.vor.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tml.vor.esb.VORUIResponse;
import com.tml.vor.esb.VORUIResponseMarshaller;
import com.tml.vor.jdgrepo.JdgVORUICustRepo;

@Service
public class VORUIServiceImpl implements VORUIService {
	
	private static Logger logger = LoggerFactory.getLogger(VORUIResponseMarshaller.class);
	private JdgVORUICustRepo jdgVORUICustRepo;
	private ObjectMapper objectMapper;
	public VORUIServiceImpl(JdgVORUICustRepo jdgVORUICustRepo) {
		this.jdgVORUICustRepo = jdgVORUICustRepo;
		this.objectMapper=new ObjectMapper();
	}	
	
	@Override
	public List<VORUIResponse> findByStartDate(String startDate) {
		logger.info("Entering Method  AccountExtractServiceImpl.findByStartDate");
		List VORUIList=jdgVORUICustRepo.findAll(startDate);
		logger.info("Exiting Method  AccountExtractServiceImpl.findByStartDate");
	 return	VORUIList;
	}

	@Override
	public List<Map> getVORUIListAsListOfMap(List<VORUIResponse> vorUIResponseList) {
		List<Map> VORUIMapList=this.objectMapper.convertValue(vorUIResponseList, new TypeReference<List<Map>>() {});

		return VORUIMapList;
	}

	

}
