package com.tml.vor.config;



public enum SearchParameters {
	
	PAR_ROW_ID("par_row_id");
	
	String value;

    public String getValue() {
        return value;
    }

    SearchParameters(String value) {
        this.value = value;
    }

}
