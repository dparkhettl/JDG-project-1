package com.tml.vor.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;


import com.tml.vor.esb.VORUIResponse;

@Component
public interface VORUIService {	
	public List<Map> getVORUIListAsListOfMap(List<VORUIResponse> vorUIResponseList);
	List<VORUIResponse> findByStartDate(String startDate);
			
}
