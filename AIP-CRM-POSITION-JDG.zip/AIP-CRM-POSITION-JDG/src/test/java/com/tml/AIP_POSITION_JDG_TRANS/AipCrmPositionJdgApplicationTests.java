package com.tml.AIP_POSITION_JDG_TRANS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AipCrmPositionJdgApplicationTests {

	@Test
	void contextLoads() {
	}

}
