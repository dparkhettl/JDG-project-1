package com.tml.AIP_VOR_JDG_TRANS.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tml.AIP_VOR_JDG_TRANS.controller.JdgVORUIController;
import com.tml.AIP_VOR_JDG_TRANS.esb.VORUIResponse;
import com.tml.AIP_VOR_JDG_TRANS.service.JdgService;




@RestController
@RequestMapping(path = "/api/vor")
public class JdgVORUIController {
	
	private static Logger logger = LoggerFactory.getLogger(JdgVORUIController.class);
    @Autowired
    JdgService jdgServiceImpl;

   @CrossOrigin
    @PostMapping(path = "/all" , produces = MediaType.APPLICATION_JSON_VALUE )
    public boolean putAll(@RequestParam("orderId")String orderId) throws Exception {
        logger.info("Entering Method  JdgVORUIController.putAll");
        try {
           
            jdgServiceImpl.putAll(orderId);

        }
        catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate {} and endDate {}", orderId);
            throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
            throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgVORUIController.putAll");
        return true;
    }

    @CrossOrigin
    @GetMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE )
    public List<VORUIResponse> getData() throws Exception {
        logger.info("Entering Method  JdgVORUIController.getData");
        List<VORUIResponse> VORUIList=null;
        try {
            VORUIList=jdgServiceImpl.getAll();
        } catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
         //  throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgVORUIController.getData");
        return VORUIList;
    }
    
    @CrossOrigin
    @PostMapping(path = "/delete" , produces = MediaType.APPLICATION_JSON_VALUE )
    public boolean delete(@RequestParam("orderId")String orderId) throws Exception {
        logger.info("Entering Method  JdgVORUIController.delete");
        try {
			
        	
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			  jdgServiceImpl.delete(orderId);

        }
        catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate {} and endDate {}", orderId);
            throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
            throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgVORUIController.delete");
        return true;
    }
    
    @CrossOrigin
    @PostMapping(path = "/search" , produces = MediaType.APPLICATION_JSON_VALUE )
   public Set<VORUIResponse> search(@RequestBody HashMap<String, String> paramMap) throws Exception{
   // public Set<VORUIResponse> search(@RequestParam("PAR_ROW_ID")String PAR_ROW_ID) throws Exception{
   //public Set<VORUIResponse> search(@RequestBody String PAR_ROW_ID) throws Exception{
        /*logger.info("Entering Method  JdgVORUIController.search");
        logger.info("Entering Method  JdgVORUIController.search"+paramMap);
        logger.info("Entering Method  JdgVORUIController.search"+paramMap.toString());
        logger.info("Entering Method  JdgVORUIController.search"+paramMap.size());*/
        Set<VORUIResponse> searchedList = null;
        try {
            searchedList = jdgServiceImpl.search(paramMap);
        }catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate and endDate");
            throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
            throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgVORUIController.search");
        return searchedList;
    }
    
   // @CrossOrigin
    @PostMapping(path = "/searchJdg" )
   public List<HashMap<String, Object>> searchJdg(@RequestBody HashMap<String, String> Mapparam) {
         logger.info("Entering Method  JdgVORUIController.search");
        logger.info("Entering Method  JdgVORUIController.search"+Mapparam.isEmpty());
        logger.info("Entering Method  JdgVORUIController.search"+Mapparam.toString());
        logger.info("Entering Method  JdgVORUIController.search"+Mapparam.size());
      //  Set<VORUIResponse> searchedList = null;
        try {
          //  searchedList = jdgServiceImpl.search(PAR_ROW_ID);
        }catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate and endDate");
            //throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
           // throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgVORUIController.search");
        return null;
    }


}
