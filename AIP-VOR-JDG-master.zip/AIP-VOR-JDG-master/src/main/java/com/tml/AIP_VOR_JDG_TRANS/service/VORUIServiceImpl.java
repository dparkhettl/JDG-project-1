package com.tml.AIP_VOR_JDG_TRANS.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.tml.AIP_VOR_JDG_TRANS.esb.VORUIResponse;
import com.tml.AIP_VOR_JDG_TRANS.esb.VORUIResponseMarshaller;
import com.tml.AIP_VOR_JDG_TRANS.jdgrepo.JdgVORUICustRepo;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class VORUIServiceImpl implements VORUIService {
	
	private static Logger logger = LoggerFactory.getLogger(VORUIResponseMarshaller.class);
	private JdgVORUICustRepo jdgVORUICustRepo;
	private ObjectMapper objectMapper;
	public VORUIServiceImpl(JdgVORUICustRepo jdgVORUICustRepo) {
		this.jdgVORUICustRepo = jdgVORUICustRepo;
		this.objectMapper=new ObjectMapper();
	}

	@Override
	public List<VORUIResponse> findByOrderId(String OrderId) {
		logger.info("Entering Method  VORUIServiceImpl.findByStartDateAndEndDate");
		List VORUIList=jdgVORUICustRepo.findAll(OrderId);
		logger.info("Exiting Method  VORUIServiceImpl.findByStartDateAndEndDate");
	 return	VORUIList;
	}

	@Override
	public List<Map> getVORUIListAsListOfMap(List<VORUIResponse> vorUIResponseList) {
		List<Map> VORUIMapList=this.objectMapper.convertValue(vorUIResponseList, new TypeReference<List<Map>>() {});

		return VORUIMapList;
	}

}
