package com.tml.AIP_VOR_JDG_TRANS.esb;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tml.AIP_VOR_JDG_TRANS.esb.VORUIResponseMarshaller;

import org.infinispan.protostream.MessageMarshaller;
import org.infinispan.protostream.MessageMarshaller.ProtoStreamReader;
import org.infinispan.protostream.MessageMarshaller.ProtoStreamWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class VORUIResponseMarshaller implements MessageMarshaller<VORUIResponse> {
	
	private static Logger logger = LoggerFactory.getLogger(VORUIResponseMarshaller.class);

    @Override
    public VORUIResponse readFrom(ProtoStreamReader protoStreamReader) throws IOException {
        logger.info("Entering Method  VORUIResponseMarshaller.readFrom");
        VORUIResponse vorUIResponse = new VORUIResponse();
        logger.info("Exiting Method  VORUIResponseMarshaller.readFrom");
        return vorUIResponse;
    }

    @Override
    public void writeTo(ProtoStreamWriter protoStreamWriter, VORUIResponse vorUIResponse) throws IOException {
        logger.info("Entering Method  VORUIResponseMarshaller.readFrom");
        ObjectMapper objectMapper = new ObjectMapper();
        HashMap<String, String> vorUIResponseMap = objectMapper.readValue(vorUIResponse.toString(), HashMap.class);
        for (Map.Entry<String, String> entry : vorUIResponseMap.entrySet()) {
            protoStreamWriter.writeString(entry.getKey(), entry.getValue());
        }
        logger.info("Exiting Method  VORUIResponseMarshaller.writeTo");
    }

    @Override
    public Class<? extends VORUIResponse> getJavaClass() {
        return VORUIResponse.class;
    }

    @Override
    public String getTypeName() {
        return "domain.VORUIResponse";
    }

}
